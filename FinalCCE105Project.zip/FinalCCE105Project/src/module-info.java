/**
 * 
 */
/**
 * 
 */
module FinalCCE105Project {
	requires java.desktop;
}