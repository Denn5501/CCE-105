package CCE105;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

// AVL Tree Node class
class AVLNode {
    int id;                      // ID of the student
    String name;                  // Student's name
    String email;                 // Student's email address
    String address;               // Student's home address
    public int height;            // Height of the node (used for balancing)
    public AVLNode right;         // Reference to the right child node
    public AVLNode left;          // Reference to the left child node

    // Constructor to initialize a new AVL node
    public AVLNode(int id, String name, String email, String address) {
        this.id = id;                      // Assign student ID
        this.name = name;                  // Assign student name
        this.email = email;                // Assign student email
        this.address = address;            // Assign student address
        this.height = 1;                   // Initial height set to 1 when node is created
    }
}

// AVL Tree class to manage the AVL tree
class AVLTree {
    private AVLNode root;                   // Root node of the AVL tree
    @SuppressWarnings("unused")
    private List<AVLNode> students; // List to store all nodes (students)

    // Constructor to initialize the AVL tree
    public AVLTree() {
        students = new ArrayList<>();       // Create an empty list to store student nodes
    }

    // Function to insert a node into the AVL tree
    public void insert(int id, String name, String email, String address) {
        root = insertRec(root, id, name, email, address); // Call the recursive function to insert
    }

    // Recursive function to find the correct place and insert the node
    private AVLNode insertRec(AVLNode node, int id, String name, String email, String address) {
        if (node == null) {                     // Base case: if the current node is empty
            System.out.println("Inserting student: " + name + " with ID: " + id); // Debugging info
            return new AVLNode(id, name, email, address); // Create and return a new node
        }
        
        // If the ID is smaller, insert in the left subtree
        if (id < node.id) {
            node.left = insertRec(node.left, id, name, email, address);
        } 
        // If the ID is larger, insert in the right subtree
        else if (id > node.id) {
            node.right = insertRec(node.right, id, name, email, address);
        } 
        // If the ID already exists, update the existing node's data
        else {
            node.name = name != null ? name : node.name;        // Update name if provided
            node.email = email != null ? email : node.email;    // Update email if provided
            node.address = address != null ? address : node.address; // Update address if provided
            return node;    // Return the updated node
        }
        
        // Update the height of the node
        node.height = 1 + Math.max(height(node.left), height(node.right));

        // Balance the tree after insertion
        return balance(node, id);
    }

    // Function to update specific fields of a node by its ID
    public void update(int id, String name, String email, String address) {
        updateRec(root, id, name, email, address);  // Call recursive update function
    }

    // Recursive function to find and update a node
    private void updateRec(AVLNode node, int id, String name, String email, String address) {
        if (node == null) { // Base case: if the node isn't found
            return; // Exit, node not found
        }

        // If the ID is smaller, go left
        if (id < node.id) {
            updateRec(node.left, id, name, email, address);
        } 
        // If the ID is larger, go right
        else if (id > node.id) {
            updateRec(node.right, id, name, email, address);
        } 
        // If found, update the node's fields
        else {
            if (name != null) {
                node.name = name; // Update name if provided
            }
            if (email != null) {
                node.email = email; // Update email if provided
            }
            if (address != null) {
                node.address = address; // Update address if provided
            }
        }

        // Update the height and balance the tree if needed
        node.height = 1 + Math.max(height(node.left), height(node.right));
        balance(node, id); // Ensure the tree is balanced
    }

    // Function to remove a node by its ID
    public void remove(int id) {
        root = removeRec(root, id); // Call recursive remove function
    }

    // Recursive function to find and remove a node
    private AVLNode removeRec(AVLNode node, int id) {
        if (node == null) {  // Base case: node not found
            return node;
        }

        // If the ID is smaller, go left
        if (id < node.id) {
            node.left = removeRec(node.left, id);
        } 
        // If the ID is larger, go right
        else if (id > node.id) {
            node.right = removeRec(node.right, id);
        } 
        // If the node to be deleted is found
        else {
            // If node has only one child or no child
            if ((node.left == null) || (node.right == null)) {
                AVLNode temp = (node.left != null) ? node.left : node.right;

                // If no child, set node to null
                if (temp == null) {
                    temp = node;
                    node = null;
                } else { // Otherwise, copy the child
                    node = temp;
                }
            } else {
                // Find the smallest node in the right subtree (in-order successor)
                AVLNode temp = minValueNode(node.right);
                node.id = temp.id;            // Replace node's data with successor's data
                node.name = temp.name;
                node.email = temp.email;
                node.address = temp.address;

                // Remove the in-order successor
                node.right = removeRec(node.right, temp.id);
            }
        }

        // If the tree becomes empty, return
        if (node == null) {
            return node;
        }

        // Update the height of the node
        node.height = Math.max(height(node.left), height(node.right)) + 1;

        // Balance the tree after deletion
        return balance(node, id);
    }

    // Function to find the node with the smallest value (in-order successor)
    private AVLNode minValueNode(AVLNode node) {
        AVLNode current = node;
        while (current.left != null) { // Find the leftmost node
            current = current.left;
        }
        return current;
    }

    // Function to clear the entire tree
    public void clear() {
        SwingUtilities.invokeLater(() -> {
            int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to clear the tree?", "Confirm",
                JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) {
                root = null; // Clear the root (and the whole tree)
                JOptionPane.showMessageDialog(null, "Tree cleared.");
            }
        });
    }

    // Function to search for a node by ID
    public AVLNode search(int id) {
        return searchRec(root, id); // Call recursive search function
    }

    // Recursive search function to find a node by ID
    private AVLNode searchRec(AVLNode node, int id) {
        if (node == null || node.id == id) { // If the node is found or reached the end
            return node; // Return the node (or null if not found)
        }
        return id < node.id ? searchRec(node.left, id) : searchRec(node.right, id); // Search left or right
    }

    // Function to search for nodes by name (partial match)
    public List<AVLNode> searchByName(String name) {
        List<AVLNode> result = new ArrayList<>(); // Create a list to store matching nodes
        searchByNameHelper(root, name.toLowerCase(), result); // Call helper to search by name
        return result; // Return the list of matching nodes
    }

    // Helper function to search for nodes by name (case-insensitive)
    private void searchByNameHelper(AVLNode node, String name, List<AVLNode> result) {
        if (node == null) {
            return;
        }
        if (node.name.toLowerCase().contains(name)) {
            result.add(node);
        }
        searchByNameHelper(node.left, name, result);
        searchByNameHelper(node.right, name, result);
    }

    // Function for in-order traversal (sorted by ID)
    public List<AVLNode> inOrderTraversal() {
        List<AVLNode> nodes = new ArrayList<>(); // Create a list to store nodes in order
        inOrderRec(root, nodes); // Call recursive function for in-order traversal
        return nodes; // Return the list of nodes in order
    }

    // Recursive function for in-order traversal
    private void inOrderRec(AVLNode node, List<AVLNode> nodes) {
        if (node != null) {
            inOrderRec(node.left, nodes);   // Visit left subtree
            nodes.add(node);                // Add current node to the list
            inOrderRec(node.right, nodes);  // Visit right subtree
        }
    }

    // Function to get the height of a node (used for balancing)
    private int height(AVLNode node) {
        return node == null ? 0 : node.height; // Return height or 0 if node is null
    }

    // Balance function to ensure the tree remains balanced
    private AVLNode balance(AVLNode node, int id) {
        int balanceFactor = getBalance(node); // Get the balance factor of the node

        // Left-heavy case (Right rotation)
        if (balanceFactor > 1 && id < node.left.id) {
            return rightRotate(node);
        }

        // Right-heavy case (Left rotation)
        if (balanceFactor < -1 && id > node.right.id) {
            return leftRotate(node);
        }

        // Left-Right case (Left-Right rotation)
        if (balanceFactor > 1 && id > node.left.id) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        // Right-Left case (Right-Left rotation)
        if (balanceFactor < -1 && id < node.right.id) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node; // Return the node after balancing
    }

    // Get the balance factor of a node
    private int getBalance(AVLNode node) {
        return node == null ? 0 : height(node.left) - height(node.right); // Difference between left and right subtree heights
    }

    // Right rotation function
    private AVLNode rightRotate(AVLNode y) {
        AVLNode x = y.left;      // Assign left child to x
        AVLNode T2 = x.right;    // Assign right child of x to T2

        x.right = y;             // Perform rotation
        y.left = T2;             // Update left child of y

        // Update heights
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x; // Return new root
    }

    // Left rotation function
    private AVLNode leftRotate(AVLNode x) {
        AVLNode y = x.right;     // Assign right child to y
        AVLNode T2 = y.left;     // Assign left child of y to T2

        y.left = x;              // Perform rotation
        x.right = T2;            // Update right child of x

        // Update heights
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y; // Return new root
    }

    public List<AVLNode> inOrder() {
        List<AVLNode> result = new ArrayList<>();
        if (root == null) {
            return result; // If the AVL tree is empty, return the empty list
        }
        performInOrderTraversal(root, result); // Call the correct traversal method
        return result; // Return the list of students
    }

    private void performInOrderTraversal(AVLNode node, List<AVLNode> result) {
        if (node != null) {
            performInOrderTraversal(node.left, result);
            result.add(node);
            performInOrderTraversal(node.right, result);
        }
    }
}

@SuppressWarnings("serial")
// AVLTableModel class to display the data of the AVL tree in a table
class AVLTableModel extends AbstractTableModel {
    private static final String[] columnNames = {"ID No", "Full Name", "Email", "Address"}; // Column names are now static final
    private final List<AVLNode> nodes; // List of nodes to display in the table

    // Constructor to initialize the table model with a list of nodes
    public AVLTableModel(List<AVLNode> nodes) {
        this.nodes = new ArrayList<>(nodes); // Create a copy of the node list
    }

    // Add a node to the table model
    public void addNode(AVLNode node) {
        SwingUtilities.invokeLater(() -> {
            nodes.add(node);
            fireTableDataChanged(); // Notify the table model to refresh
        });
    }

    // Clear all nodes from the table model
    public void clearNodes() {
        SwingUtilities.invokeLater(() -> {
            nodes.clear();
            fireTableDataChanged(); // Notify the table model to refresh
        });
    }

    // Return the number of rows (number of nodes)
    @Override
    public int getRowCount() {
        return nodes.size(); // Number of rows equals number of nodes
    }

    // Return the number of columns (fixed: 4 columns)
    @Override
    public int getColumnCount() {
        return columnNames.length; // 4 columns: ID, Name, Email, Address
    }

    // Return the value at a specific cell
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        AVLNode node = nodes.get(rowIndex); // Get the node at the specified row
        switch (columnIndex) {
            case 0: return node.id;        // ID column
            case 1: return node.name;      // Name column
            case 2: return node.email;     // Email column
            case 3: return node.address;   // Address column
            default: return null;
        }
    }

    // Return the name of a specific column
    @Override
    public String getColumnName(int column) {
        return columnNames[column]; // Return the name of the column
    }
}

