package CCE105;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JComboBox;

public class StudentManagementSystem extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField idField;
	private JTextField nameField;
	private JTextField emailField;
	private JTextField addressField;
	private JTable table;
	private JTextField searchField;
	protected AVLTree avlTree;
	private DefaultTableModel tableModel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentManagementSystem frame = new StudentManagementSystem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("serial")
	public StudentManagementSystem() {
	    setResizable(false);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 1240, 810);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(143, 22, 44));
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

	    setContentPane(contentPane);
	    contentPane.setLayout(null);

	    
	    avlTree = new AVLTree();
	    
	    tableModel = new DefaultTableModel(new Object[]{"ID", "Name", "Email", "Address"}, 0) {
	    public boolean isCellEditable(int row, int column) {
	        return false; // All cells are not editable
	    }
	};

	    
	    table = new JTable(tableModel);
	    table.getTableHeader().setReorderingAllowed(false);
	    table.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font size for table content
	    table.setRowHeight(30);  // Adjust the row height to match larger font size
	    table.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 20));  // Set font size for header
	    table.setBounds(365, 106, 832, 600);
	    contentPane.add(table);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane(table);
	    scrollPane.setBounds(365, 106, 832, 600);
	    contentPane.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("Student \r\nManagement System");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Lucida Fax", Font.PLAIN, 22));
		lblNewLabel.setBounds(10, 11, 340, 76);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel.setBackground(new Color(143, 22, 44));
		panel.setBounds(20, 106, 300, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel IDNoLabel = new JLabel("ID No.");
		IDNoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		IDNoLabel.setBounds(110, 11, 69, 29);
		IDNoLabel.setForeground(new Color(255, 255, 255));
		IDNoLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
		panel.add(IDNoLabel);
		
		idField = new JTextField();
		idField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		idField.setHorizontalAlignment(SwingConstants.CENTER);
		idField.setBounds(29, 51, 240, 35);
		panel.add(idField);
		idField.setColumns(10);
		
		JLabel lblFirstName = new JLabel("Full Name");
		lblFirstName.setHorizontalAlignment(SwingConstants.CENTER);
		lblFirstName.setForeground(Color.WHITE);
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblFirstName.setBounds(81, 97, 130, 29);
		panel.add(lblFirstName);
		
		nameField = new JTextField();
		nameField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		nameField.setHorizontalAlignment(SwingConstants.CENTER);
		nameField.setColumns(10);
		nameField.setBounds(29, 137, 240, 35);
		panel.add(nameField);
		
		emailField = new JTextField();
		emailField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		emailField.setHorizontalAlignment(SwingConstants.CENTER);
		emailField.setColumns(10);
		emailField.setBounds(29, 223, 240, 35);
		panel.add(emailField);
		
		JLabel lblLastName = new JLabel("Email");
		lblLastName.setHorizontalAlignment(SwingConstants.CENTER);
		lblLastName.setForeground(Color.WHITE);
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblLastName.setBounds(81, 183, 130, 29);
		panel.add(lblLastName);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setHorizontalAlignment(SwingConstants.CENTER);
		lblAddress.setForeground(Color.WHITE);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblAddress.setBounds(81, 269, 130, 29);
		panel.add(lblAddress);
		
		addressField = new JTextField();
		addressField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		addressField.setHorizontalAlignment(SwingConstants.CENTER);
		addressField.setColumns(10);
		addressField.setBounds(29, 309, 240, 35);
		panel.add(addressField);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(e -> {
		    try {
		        // Get and trim ID input from idField, converting it to an integer
		        int id = Integer.parseInt(idField.getText().trim());
		        
		        // Get and trim inputs from nameField, emailField, and addressField
		        String name = nameField.getText().trim();
		        String email = emailField.getText().trim();
		        String address = addressField.getText().trim();

		        // Check if a student with this ID already exists in the AVL tree
		        AVLNode existingNode = avlTree.search(id); // Assuming avlTree.search() method returns a node by ID
		        if (existingNode != null) {
		            // If a student with the same ID is found, show a message and exit the method
		            JOptionPane.showMessageDialog(null, "A student with ID " + id + " already exists.");
		            return; // Exit if the ID is already in the AVL tree
		        }

		        // Proceed with inserting the new student into the AVL tree
		        avlTree.insert(id, name, email, address); // Insert the new student
		        // Add the new student details as a row in the table model
		        tableModel.addRow(new Object[]{id, name, email, address});
		        
		        // Show a confirmation dialog indicating successful addition
		        JOptionPane.showMessageDialog(null, "Student added successfully!");
		        
		        // Clear the input fields after insertion to prepare for new input
		        clearFields(); // Method to reset the input fields

		    } catch (NumberFormatException ex) {
		        // If the input for ID is not a valid integer, show an error message
		        JOptionPane.showMessageDialog(null, "Invalid input for ID. Please enter a valid number.");
		    } catch (Exception ex) {
		        // Catch any other exceptions and display the error message
		        JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
		    }
		});
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnAdd.setBounds(31, 392, 100, 45);
		panel.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(e -> {
		    try {
		        // Get and trim ID input from idField, converting it to an integer
		        int id = Integer.parseInt(idField.getText().trim());
		        
		        // Get and trim inputs from nameField, emailField, and addressField
		        String name = nameField.getText().trim();
		        String email = emailField.getText().trim();
		        String address = addressField.getText().trim();

		        // Check if the student with the specified ID exists in the AVL tree
		        AVLNode existingNode = avlTree.search(id); // Assuming you have a search method in AVLTree
		        if (existingNode == null) {
		            // If the student is not found, show a message and exit the method
		            JOptionPane.showMessageDialog(null, "Student with ID " + id + " not found.");
		            return; // Exit if ID is not found
		        }

		        // Update fields in the existingNode only if the user has provided non-empty input
		        if (!name.isEmpty()) {
		            existingNode.name = name; // Update name if input is not empty
		        }
		        if (!email.isEmpty()) {
		            existingNode.email = email; // Update email if input is not empty
		        }
		        if (!address.isEmpty()) {
		            existingNode.address = address; // Update address if input is not empty
		        }

		        // Update the corresponding row in the table model
		        for (int i = 0; i < tableModel.getRowCount(); i++) {
		            // Check if the row's ID matches the ID to update
		            if (Integer.parseInt(tableModel.getValueAt(i, 0).toString()) == id) {
		                // Update the respective fields in the table model
		                tableModel.setValueAt(existingNode.name, i, 1);  // Update name in the table
		                tableModel.setValueAt(existingNode.email, i, 2); // Update email in the table
		                tableModel.setValueAt(existingNode.address, i, 3); // Update address in the table
		                break; // Exit the loop once the row is updated
		            }
		        }

		        // Show a confirmation dialog to indicate successful update
		        JOptionPane.showMessageDialog(null, "Details updated!");
		        
		        // Clear the input fields after updating
		        clearFields(); // Method to reset the input fields

		    } catch (NumberFormatException ex) {
		        // If the input for ID is not a valid integer, show an error message
		        JOptionPane.showMessageDialog(null, "Invalid input for ID. Please enter a valid number.");
		    } catch (Exception ex) {
		        // Catch any other exceptions and display the error message
		        JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
		    }
		});
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnUpdate.setBounds(169, 392, 100, 45);
		
		panel.add(btnUpdate);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Get the ID entered by the user from the idField and parse it to an integer
		            int id = Integer.parseInt(idField.getText());

		            // Remove the student with the specified ID from the AVL tree
		            avlTree.remove(id);

		            // Loop through the table rows to find the row with the matching ID
		            for (int i = 0; i < tableModel.getRowCount(); i++) {
		                // Compare the ID in the current row with the ID to be removed
		                if (Integer.parseInt(tableModel.getValueAt(i, 0).toString()) == id) {
		                    // If the ID matches, remove the row from the table model
		                    tableModel.removeRow(i);
		                    break; // Exit the loop once the row is found and removed
		                }
		            }

		            // Show a confirmation dialog to indicate that the student details have been removed
		            JOptionPane.showMessageDialog(null, "Details removed!");

		        } catch (NumberFormatException ex) {
		            // If the input is not a valid integer (ID), show an error message
		            JOptionPane.showMessageDialog(null, "Invalid input for ID.");
		        }
		    }
		});
		btnRemove.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnRemove.setBounds(29, 466, 100, 45);
		panel.add(btnRemove);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(e -> clearFields());
		btnClear.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnClear.setBounds(169, 466, 100, 45);
		panel.add(btnClear);
		
		table = new JTable();
		table.setBounds(365, 106, 832, 600);
		contentPane.add(table);
		
		JLabel searchLabel = new JLabel("Search By:");
		searchLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		searchLabel.setForeground(new Color(255, 255, 255));
		searchLabel.setBounds(360, 72, 87, 22);
		contentPane.add(searchLabel);
		
		String[] searchOptions = {"ID", "Name"};
		JComboBox<String> comboBox = new JComboBox<>(searchOptions);
		comboBox.setBounds(445, 70, 120, 25);
		contentPane.add(comboBox);
		
		searchField = new JTextField();
		searchField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		searchField.setBounds(702, 70, 200, 25);
		contentPane.add(searchField);
		searchField.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(e -> {
		    String searchTerm = searchField.getText().trim(); // Get the search term from the input field and trim any leading/trailing spaces
		    String selectedSearch = comboBox.getSelectedItem().toString(); // Get the selected search option (either "ID" or "Name")

		    // Check if the search term is empty
		    if (searchTerm.isEmpty()) {
		        JOptionPane.showMessageDialog(null, "Please enter an ID or name to search."); // Show a message dialog if search field is empty
		        return; // Exit the method if the input is empty
		    }

		    tableModel.setRowCount(0); // Clear any existing data from the table before displaying new search results

		    try {
		        if (selectedSearch.equals("ID")) {
		            // Search by ID
		            int id = Integer.parseInt(searchTerm); // Convert the search term to an integer (for searching by ID)
		            AVLNode student = avlTree.search(id); // Call the search method in AVL tree to find a student by ID

		            if (student != null) {
		                // If a student is found, add their information to the table
		                tableModel.addRow(new Object[]{student.id, student.name, student.email, student.address});
		            } else {
		                // If no student is found with the entered ID, show a message dialog
		                JOptionPane.showMessageDialog(null, "No student found with ID " + id);
		            }
		        } else if (selectedSearch.equals("Name")) {
		            // Search by Name
		            List<AVLNode> students = avlTree.searchByName(searchTerm); // Call the searchByName method to find students with the given name

		            if (students.isEmpty()) {
		                // If no students are found with the given name, show a message dialog
		                JOptionPane.showMessageDialog(null, "No student found with name " + searchTerm);
		            } else {
		                // If one or more students are found, loop through the list and add each student's details to the table
		                for (AVLNode student : students) {
		                    tableModel.addRow(new Object[]{student.id, student.name, student.email, student.address});
		                }
		            }
		        }
		    } catch (NumberFormatException ex) {
		        // Handle the case where the input is not a valid number for searching by ID
		        JOptionPane.showMessageDialog(null, "Invalid input for ID. Please enter a valid number.");
		    }
		});
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSearch.setBounds(932, 70, 90, 25);
		contentPane.add(btnSearch);
		
		
		JButton btnShowAll = new JButton("Show All");
		btnShowAll.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        tableModel.setRowCount(0); // Clear existing data from the table

		        List<AVLNode> students = avlTree.inOrder(); // Fetch all students using the inOrder method

		        // Check if the students list is null or empty
		        if (students == null || students.isEmpty()) {
		            // If no students are found, display a message dialog
		            JOptionPane.showMessageDialog(null, "No students found!");
		        } else {
		            // Populate the table with all students' data
		            for (AVLNode student : students) {
		                // Add each student's details (ID, Name, Email, Address) to a new row in the table
		                tableModel.addRow(new Object[]{student.id, student.name, student.email, student.address});
		            }
		        }
		    }
		});
		btnShowAll.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnShowAll.setBounds(1063, 70, 90, 25);
		contentPane.add(btnShowAll);
	}

	private void clearFields() {
		  idField.setText("");
	      nameField.setText("");
	      emailField.setText("");
	      addressField.setText(""); // Changed for clarity
	      searchField.setText(""); // Clear search field too
		
	}
}
